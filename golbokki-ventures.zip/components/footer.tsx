export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-primary">Golbokki Ventures</h3>
            <p className="text-sm text-muted">
              Premium Nigerian Rice — Clean, Fresh & Consistent. Your trusted partner for quality rice products.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Products</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <a href="#products" className="hover:text-primary transition-colors">
                  Parboiled Long-Grain
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-primary transition-colors">
                  White Long-Grain
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-primary transition-colors">
                  Premium Select
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Services</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <a href="#services" className="hover:text-primary transition-colors">
                  Toll Milling
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-primary transition-colors">
                  Custom Packaging
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-primary transition-colors">
                  Nationwide Delivery
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Company</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <a href="#about" className="hover:text-primary transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-primary transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-muted/20 mt-12 pt-8 text-center">
          <p className="text-sm text-muted">© 2025 Golbokki Ventures. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
