import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function FAQSection() {
  const faqs = [
    {
      question: "Do you deliver nationwide?",
      answer:
        "Yes, we provide delivery services across all states in Nigeria. Our logistics network ensures your rice reaches you fresh and on time, typically within 3-5 business days.",
    },
    {
      question: "What packaging sizes are available?",
      answer:
        "We offer three convenient packaging sizes: 10kg, 25kg, and 50kg bags. All packages are made with high-quality materials and feature secure sealing to maintain freshness.",
    },
    {
      question: "Do you offer private-label packaging?",
      answer:
        "Yes, we provide private-label packaging services for businesses and distributors. You can have your brand name and design on our premium rice packages with minimum order quantities.",
    },
    {
      question: "What are your minimum order quantities (MOQs)?",
      answer:
        "Our MOQs vary by packaging size: 10kg bags (minimum 50 bags), 25kg bags (minimum 20 bags), and 50kg bags (minimum 10 bags). Contact us for bulk order discounts.",
    },
    {
      question: "How long are your lead times?",
      answer:
        "Standard lead times are 3-5 business days for most orders. We also offer express processing for urgent orders, which can be completed within 1-2 business days for an additional fee.",
    },
    {
      question: "What makes your rice different from others?",
      answer:
        "Our rice undergoes rigorous quality control including moisture checks, de-stoning, broken grain separation, and hygienic packaging with traceable codes. We ensure stone-free, consistently clean rice every time.",
    },
  ]

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Find answers to common questions about our rice products and services.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
                <AccordionTrigger className="text-left font-semibold">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground pt-2">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
