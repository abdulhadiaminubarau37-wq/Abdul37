import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function ProductsSection() {
  const products = [
    {
      name: "Parboiled Long-Grain",
      description: "Premium parboiled rice with enhanced nutritional value and extended shelf life.",
      features: ["Stone-free", "Extra long grain", "Rich in nutrients", "Perfect texture"],
      image: "/placeholder-dhozy.png",
    },
    {
      name: "White Long-Grain",
      description: "Classic white rice with excellent cooking properties and consistent quality.",
      features: ["Pure white", "Fluffy texture", "Quick cooking", "Versatile use"],
      image: "/placeholder-vkmbg.png",
    },
    {
      name: "Premium Select",
      description: "Our finest grade rice, carefully selected for superior quality and taste.",
      features: ["Hand-selected", "Premium grade", "Exceptional taste", "Restaurant quality"],
      image: "/placeholder-1g79z.png",
    },
  ]

  const packagingSizes = ["10kg", "25kg", "50kg"]

  return (
    <section id="products" className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Our Rice Products</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our range of premium rice varieties, available in flexible packaging sizes to meet your needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {products.map((product, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">{product.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{product.description}</p>
                <div className="flex flex-wrap gap-2">
                  {product.features.map((feature, featureIndex) => (
                    <Badge key={featureIndex} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-muted/30 rounded-lg p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Packaging Options</h3>
            <p className="text-muted-foreground">
              All our rice varieties are available in multiple packaging sizes to suit your requirements.
            </p>
          </div>
          <div className="flex justify-center gap-8">
            {packagingSizes.map((size, index) => (
              <div key={index} className="text-center">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <span className="text-2xl font-bold text-primary">{size}</span>
                </div>
                <p className="text-sm text-muted-foreground">Available</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
