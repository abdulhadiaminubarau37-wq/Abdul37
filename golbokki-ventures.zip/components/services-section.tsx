import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Wheat, Package, Truck, Clock } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Wheat,
      title: "Toll Milling for Farmers",
      description:
        "We provide comprehensive milling services for farmers, including cleaning, milling, polishing, and bagging of your rice.",
      features: ["Professional cleaning", "Precision milling", "Quality polishing", "Custom bagging"],
    },
    {
      icon: Package,
      title: "Custom Packaging",
      description:
        "Flexible packaging options in 10kg, 25kg, and 50kg bags with your branding or our premium packaging.",
      features: ["Multiple sizes", "Custom branding", "Quality materials", "Secure sealing"],
    },
    {
      icon: Truck,
      title: "Nationwide Delivery",
      description: "Reliable delivery services across Nigeria ensuring your rice reaches you fresh and on time.",
      features: ["Nationwide coverage", "Timely delivery", "Safe transport", "Order tracking"],
    },
    {
      icon: Clock,
      title: "Quick Turnaround",
      description: "Standard lead times of 3-5 business days for most orders, with express options available.",
      features: ["3-5 day standard", "Express options", "Flexible scheduling", "Priority handling"],
    },
  ]

  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Our Services</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive rice processing and delivery services designed to meet your specific needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <service.icon className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-sm text-muted-foreground flex items-center justify-center">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
