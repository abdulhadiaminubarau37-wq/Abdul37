import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Leaf, Users, Recycle } from "lucide-react"

export function SustainabilitySection() {
  const initiatives = [
    {
      icon: Users,
      title: "Fair Farmer Partnerships",
      description: "We work directly with local farmers, ensuring fair prices and supporting rural communities.",
      impact: "Supporting 200+ local farmers",
    },
    {
      icon: Recycle,
      title: "Husk Reuse Program",
      description: "Rice husks are converted into organic fertilizer and biomass fuel, reducing waste.",
      impact: "Zero waste production",
    },
    {
      icon: Leaf,
      title: "Job Creation",
      description: "Creating employment opportunities in rural areas and contributing to local economic growth.",
      impact: "50+ direct jobs created",
    },
  ]

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Sustainability & Community</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Building a sustainable future through responsible farming partnerships and community development.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {initiatives.map((initiative, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <initiative.icon className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl">{initiative.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{initiative.description}</p>
                <div className="bg-secondary/10 rounded-lg p-3">
                  <p className="text-sm font-semibold text-secondary">{initiative.impact}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
