import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="relative bg-gradient-to-br from-primary/5 to-secondary/5 py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
                Premium Nigerian Rice —<span className="text-primary"> Clean, Fresh & Consistent</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl">
                Golbokki Ventures mills, packages, and delivers rice in 10kg, 25kg, and 50kg bags.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Request a Quote
              </Button>
              <Button size="lg" variant="outline">
                View Products
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-8">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Stone-free</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Hygienic packaging</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Nationwide delivery</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Reliable supply</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <img
              src="/placeholder-no326.png"
              alt="Premium Nigerian rice and milling facility"
              className="rounded-lg shadow-2xl w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
