import { Card, CardContent } from "@/components/ui/card"
import { Shield, Droplets, Filter, Package2, Award, Microscope } from "lucide-react"

export function QualitySection() {
  const qualitySteps = [
    {
      icon: Droplets,
      title: "Moisture Checks",
      description: "Rigorous moisture content testing ensures optimal storage and cooking quality.",
    },
    {
      icon: Filter,
      title: "De-stoning Process",
      description: "Advanced de-stoning technology removes all foreign materials for pure rice.",
    },
    {
      icon: Microscope,
      title: "Grain Separation",
      description: "Precision separation removes broken grains for consistent quality.",
    },
    {
      icon: Package2,
      title: "Hygienic Bagging",
      description: "Clean, traceable packaging with quality codes for full traceability.",
    },
  ]

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Quality Assurance</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive quality control process ensures every grain meets our high standards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {qualitySteps.map((step, index) => (
            <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="space-y-4">
                <div className="mx-auto w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center">
                  <step.icon className="h-8 w-8 text-secondary" />
                </div>
                <h4 className="text-lg font-semibold">{step.title}</h4>
                <p className="text-muted-foreground text-sm">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Shield className="h-12 w-12 text-primary" />
                <div>
                  <h3 className="text-2xl font-bold text-foreground">Certifications & Standards</h3>
                  <p className="text-muted-foreground">Committed to meeting the highest industry standards</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-secondary" />
                  <span className="text-foreground">NAFDAC Certified (Pending)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-secondary" />
                  <span className="text-foreground">ISO Quality Standards</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-secondary" />
                  <span className="text-foreground">Food Safety Compliance</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="/rice-quality-control-lab.png"
                alt="Quality control process"
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
